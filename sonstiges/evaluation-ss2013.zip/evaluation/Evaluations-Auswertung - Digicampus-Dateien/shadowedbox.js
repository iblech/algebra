
jQuery(document).ready(function()
{
   
    jQuery("ul#tabs2~*:not(.studipfooter):not(:empty)"). addClass("shadowed_box");
    jQuery(".index_box").addClass("shadowed_box");
    $(".blank").first().addClass("shadowed_box");
});

